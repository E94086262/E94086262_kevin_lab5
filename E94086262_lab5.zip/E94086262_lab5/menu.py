import pygame
import os

Image_Menu = pygame.image.load(os.path.join("images", "upgrade_menu.png")) #引入圖檔
Upgrade_Button = pygame.transform.scale(pygame.image.load(os.path.join("images", "upgrade.png")), (60, 50))
Sell_Button = pygame.transform.scale(pygame.image.load(os.path.join("images", "sell.png")), (50, 50))
class UpgradeMenu:
    def __init__(self, x, y):
        self.image = pygame.transform.scale(Image_Menu, (200, 200))  # image of the upgrade menu
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.__buttons = [Button(Upgrade_Button,'upgrade',self.rect.centerx,self.rect.centery-70),
                          Button(Sell_Button,'sell',self.rect.centerx,self.rect.centery+75)] # (Q2) Add buttons here

    def draw(self, win):
        """
        (Q1) draw menu itself and the buttons
        (This method is call in draw() method in class TowerGroup)
        :return: None
        """
        # draw menu
        win.blit(self.image,self.rect)
        # draw button
        # (Q2) Draw buttons here
        for but in self.__buttons:
            win.blit(but.image, but.rect)
        pass

    def get_buttons(self):
        """
        (Q1) Return the button list.
        (This method is call in get_click() method in class TowerGroup)
        :return: list
        """
        return self.__buttons
        pass


class Button:
    def __init__(self, image, name, x, y):
        self.name = name
        self.image = image  # image of the button
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def clicked(self, x, y):
        """
        (Q2) Return Whether the button is clicked
        (This method is call in get_click() method in class TowerGroup)
        :param x: mouse x
        :param y: mouse y
        :return: bool
        """
        return True if self.rect.collidepoint(x, y) else False
        pass

    def response(self):
        """
        (Q2) Return the button name.
        (This method is call in get_click() method in class TowerGroup)
        :return: str
        """
        return self.name
        pass






